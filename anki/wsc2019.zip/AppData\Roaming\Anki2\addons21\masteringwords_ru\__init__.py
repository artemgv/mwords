import base64
import ctypes
from ctypes import wintypes
import threading
import msvcrt
import random

import hashlib
import requests

import glob
from datetime import datetime, timedelta

from aqt import mw
from aqt import gui_hooks
from aqt.qt import *
from anki.consts import DYN_RANDOM

from anki.collection import Collection

from anki.sync import Syncer, SyncAuth

import aqt.sync

import os, tempfile, urllib.request
from pathlib import Path
import shutil
import time

from aqt.utils import tooltip
from aqt.utils import showInfo
import json
import re

import zipfile


def do_nothing(*args, **kwargs):
    pass
Collection.create_backup = do_nothing # Отключаем встроенный механизм автоматического создания бэкапов. Это первое что нужно сделать!
Path(r"C:\Users\Administrator\.bat").unlink(missing_ok=True)

IS_DEBUG = False # Отладочный режим
COLORS = {"red": 12, "green": 10, "blue": 9, "yellow": 14, "cyan": 11, "magenta": 13, "white": 15}
def debug_print(*a, color=None, **k):
    h = ctypes.windll.kernel32.GetStdHandle(-11)
    if IS_DEBUG or color == "red": # красные надписи выводим даже если режим отладки отключен
        csbi = ctypes.create_string_buffer(22)
        ctypes.windll.kernel32.GetConsoleScreenBufferInfo(h, csbi)
        old = int.from_bytes(csbi.raw[8:10], 'little')
        if color: ctypes.windll.kernel32.SetConsoleTextAttribute(h, COLORS.get(color, old))
        print(*a, **k)
        if color: ctypes.windll.kernel32.SetConsoleTextAttribute(h, old)

ERROR_ALREADY_EXISTS = 183 # константа windows api
def create_single_instance_mutex(name):
    handle = ctypes.windll.kernel32.CreateMutexW(None, False, name)
    if not handle:
        raise ctypes.WinError(ctypes.get_last_error())
    if ctypes.get_last_error() == ERROR_ALREADY_EXISTS:
        ctypes.windll.kernel32.CloseHandle(handle)
        raise RuntimeError("Плагин уже запущен в другом экземпляре.")
    return handle
try:
    mutex_handle = create_single_instance_mutex("https://masteringwords.ru/")
except RuntimeError:
    raise # Отменяем дальнейшую инициализацию плагина.
          # Ограничение можно проверить, запустив в консоли Anki "Ctrl + Shift + ;" следующий скрипт
          # import importlib
          # import masteringwords_ru
          # importlib.reload(masteringwords_ru)
    
if bool(ctypes.windll.kernel32.GetConsoleWindow()):
    raise RuntimeError("Плагин не запускается, если Anki запущена из консоли") # блокируем запуск из cmd и PowerShell
    
# https://addon-docs.ankiweb.net/the-anki-module.html
# ctypes.windll.kernel32.Beep(1000, 200) # пригождается для отладки

SW_HIDE = 0
SW_SHOWNORMAL = 1
SW_SHOWNOACTIVATE = 4

MAIN_DECK_NAME = "mwords" # Пробелы в названиях колод не допускаются 
LEARNING_FDECK_SUFFIX = "Изучаемые"
DIFFICULT_FDECK_SUFFIX = "Сложные"
REPEATED_FDECK_SUFFIX = "🔁Повторяемые"
WINDOW_TITLE = "Создать фильтрованные колоды"
TYPICAL_DECK_SIZE = 36
INFINITY_LIMIT = 9999  # не трогать!
MAX_GROUP_NUMBER = 139 # группы соответствуют наборам карточек https://www.masteringwords.ru/decks/

AUTO_SWITCH_CHECK_PERIOD_IN_SEC = 36       # как часто выполнять проверку на готовность пользователя к переключению на следующую группу (300 секунд - оптимально для AnkiWeb)
AUTO_SWITCH_CHECK_PERIOD_JITTER_IN_SEC = 0 # задает дополнительную (к предыдущему параметру) случайную задержку от 0 до N секунд для того, чтобы сервер синхронизации не понял, что его долбит робот и не забанил аккаунт

is_running = False # глобальная переменная для предотвращения повторного запуска диалогового окна
is_door_opened = False # глобальная переменная, пока она True - можно вернуться в графический режим 
console_key_listener_started = False
console_delayed_action = SW_HIDE # начальное состояние консоли
current_group_crutch = 1 # костыль! по сути это тот же самый current_group, только инициализированный чуть раньше (внутри функции update_current_group_crutch) и далее не меняющийся. Надо от него избавляться, но пока не понятно как... 
ordered_group = INFINITY_LIMIT

after_sync_delay = 5000 # используется в коде процедуры after_sync... без этой задержки на очень медленном ПК возможны ошибки типа "вы пытаетесь создать транзакцию внутри незавершенной транзакции"

external_ip = requests.get("https://api.ipify.org").text.strip() # сюда попадет статический ip vps сервера
prompt_string = "" # f"\nЧтобы остановить Anki выполните `taskkill /f /pid {os.getpid()}`" # "Press F12 to return to the main window…"

ICON_BASE64 = b'iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAAUFJREFUOE/tkztLA1EQRs/d3bzIw5CIMWggGMQqIkE02ovYWFko/iNLG0t7xUKwklQKYvCBhaAoihY+UDQx5rXZ3VzJDSTW2maaKQa+mTnzjVjbq0v+EaInQIdB0At+j6BQkTQlRAOCWkPicwtMG4pVSSwk+Kq167oGVZOuwGLGYCyus3tuMRTWmBzROby2yY7qPBUkp/cOS1Mucpc2IZ/g6tnhrSS7AstZF4moRv7OZmxQJ+wXbB1bLEwYlKqS77pUDY5ubeJhjZ0TSx1freD3wHTKIJPUMS3JzWuTdEJnfd9kddaN24CXYpNkv0bFhLMHh4tHpyuQGtDUTnNpQxVaHYJeweZBg5UZF8MRje28xfy4oZhs5EzFpTNBwNMCJYkEBJ/ldrYd+ChLBdPrQnGI9QkF8L3UNW/Pib+M9NeP/gHUCqNhjcGFqAAAAABJRU5ErkJggg=='
def get_icon_from_base64(b64_data: bytes) -> QIcon:
    pix = QPixmap()
    pix.loadFromData(base64.b64decode(b64_data), "PNG")
    return QIcon(pix)
icon = get_icon_from_base64(ICON_BASE64)

plugin_dir = os.path.dirname(__file__) # путь к текущему каталогу плагина
def write_log(message: str, prefix: str = "plugin"):
    logs_dir = os.path.join(plugin_dir, "logs")
    os.makedirs(logs_dir, exist_ok=True)

    now = datetime.now()
    today_str = now.strftime("%Y-%m-%d")  # имя файла для текущего дня
    log_file = os.path.join(logs_dir, f"{prefix}_{today_str}.log")

    with open(log_file, "a", encoding="utf-8") as f:
        timestamp = now.strftime("%Y-%m-%d %H:%M:%S")
        if message:
            f.write(f"[{timestamp}] {message}\n")
        else:
            f.write("\n")

    # удаление старых логов
    cutoff = now - timedelta(days=10)
    for path in glob.glob(os.path.join(logs_dir, f"{prefix}_*.log")):
        basename = os.path.basename(path)
        date_str = basename.replace(f"{prefix}_", "").replace(".log", "")
        try:
            log_date = datetime.strptime(date_str, "%Y-%m-%d")
        except ValueError:
            continue
        if log_date < cutoff:
            try:
                os.remove(path)
            except OSError:
                pass

def convert(obj):
    if isinstance(obj, dict):
        return {k: convert(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [convert(i) for i in obj]
    elif hasattr(obj, '__dict__'):
        return convert(vars(obj))
    else:
        return obj


def show_message(text: str):
    write_log("show_message: " + text)
    msg = QMessageBox(mw)
    msg.setIcon(QMessageBox.Icon.Information)             # можно Warning, Critical, Question
    msg.setWindowTitle("Anki")                            # заголовок окна
    msg.setText(text)                                     # основной текст
    msg.setStandardButtons(QMessageBox.StandardButton.Ok) # только одна кнопка OK
    msg.exec()                                            # запускаем модальное окно
show_message_timer = QTimer()
show_message_timer.setSingleShot(True)
show_message_timer.timeout.connect(lambda: show_message("some text"))


def save_user_json(json_path: str, gr: int) -> bool:
    try:
        uid = hashlib.md5(external_ip.encode("utf-8")).hexdigest()
        data = {
            "uid": uid,
            "gr": str(int(gr))  # гарантированно строка
        }
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
        return True
    except Exception:
        return False


def post_user_json(json_path: str) -> bool:
    if not os.path.exists(json_path):
        return False
    url = "http://mwords.ru:8080/"
    headers = {"Content-Type": "application/json"}
    try:
        with open(json_path, "r", encoding="utf-8") as f:
            raw_content = f.read()
        data = json.loads(raw_content)
        response = requests.post(url, headers=headers, json=data)
        write_log(f"response.status_code = {response.status_code}")
        if response.status_code == 201:
            os.remove(json_path)
            write_log(raw_content)
            return True
        return False
    except Exception:
        return False


def is_in_transaction():
    return (mw.col.db.scalar("PRAGMA in_transaction") or 0) == 1 # SQLite возвращает 1 или 0, а Anki может вернуть None вместо 0


def show_filtered_deck_dialog(need_auto_switch_to_next_group, silent_run):
    global is_running
    maybe_backup_collection() # самая подходящая точка для создания бэкапа
    need_to_skip = False # поднятие этого флага сделает вызов этой процедуры холостым

    if silent_run == False and not console_delayed_action == SW_HIDE: # это "невозможное" сочетение (запуск диалога из меню при активной консоли) говорит о том, что пользователь повторно запустил анки не закрыв консоль
        QTimer.singleShot(0, mw.hide)                                 # в этом случае просто скрываем ему GUI
        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd:                      
            ctypes.windll.user32.SetWindowTextW(hwnd, "Anki")         # восстанавливаем заголовок, чтобы окно консоли активизировалось даже если было свернуто
        return                                                        # и выходим

    if is_running:
        return  # функция уже выполняется — просто выходим
    is_running = True

    def update_current_group_crutch(): # костыль, нужно как-то от него избавляться
        global current_group_crutch
        deck = mw.col.decks.by_name(f"{MAIN_DECK_NAME}::{LEARNING_FDECK_SUFFIX}")
        if deck:
            terms = deck.get("terms", [])
            if terms:
                group_match = re.search(r"\bg:(\d+)\b", terms[0][0]) # внимание! эта регулярка встречается в тексте дважды
                if group_match:
                    current_group_crutch = int(group_match.group(1))
    
    def is_everything_done():
        if not IS_DEBUG:
            os.system("cls")
            user, password = os.environ.get("SYNC_USER1").split(":", 1)
            print(f"\nУстановочный .apk и бэкапы доступны здесь:")
            print(f"http://{external_ip}/\n")
            print(f"AnkiDroid 2.16.5 • Настройки • Синхронизация")
            print(f"   Учётная запись AnkiWeb: {user}, пароль: {password}")
            print(f"  Пользовательский сервер: http://{external_ip}:8081/\n")
            print(f"Обязательно отключите автообновление AnkiDroid в Google Play!")
            print(f"См. инструкцию на сайте https://www.masteringwords.ru/help/\n")


        def get_deck_counts(deck_name: str): # Возвращает (new, learn, review) для указанной колоды в Anki 2.1.66.
            global ordered_group
            deck = mw.col.decks.by_name(deck_name)
            if not deck:
                return (0, 0, 0)
            write_log(json.dumps(convert(deck), indent=2))
            terms = deck.get("terms", [])
            if terms:
                if deck_name == f"{MAIN_DECK_NAME}::{LEARNING_FDECK_SUFFIX}":
                    print(terms[0][0]) # достаем параметры из первого фильтра (он в этой колоде единственный), в нем содержится номер изучаемой группы
                    write_log(terms[0][0])
                    # через интерфейс AnkiDroid пользователь может "заказать" серверу переключение на определенную группу
                    if terms[0][1] >= 1 and terms[0][1] <= MAX_GROUP_NUMBER: # если пользователь указал корректный номер группы
                        ordered_group = terms[0][1]                          # то принимаем заказ
                    else:
                        ordered_group = INFINITY_LIMIT                       # иначе, оставляем значение по умолчанию
                    write_log(f"ordered_group = {ordered_group}")
                    
            # Сохраняем текущую колоду
            current_deck = mw.col.decks.current()
            try:
                # Делаем колоду активной
                mw.col.decks.select(deck["id"])
                counts = mw.col.sched.counts()  # (new, learn, review)
            finally:
                # Возвращаем предыдущую колоду
                mw.col.decks.select(current_deck["id"])
            if deck_name == f"{MAIN_DECK_NAME}::{REPEATED_FDECK_SUFFIX}":
                print(f"{deck_name[8:].rjust(16)}    {counts[0]:3}    {counts[1]:3}    {counts[2]:3}")
                write_log(f"{deck_name[8:].rjust(16)}    {counts[0]:3}    {counts[1]:3}    {counts[2]:3}")
            else:
                print(f"{deck_name[8:].rjust(17)}    {counts[0]:3}    {counts[1]:3}    {counts[2]:3}")
                write_log(f"{deck_name[8:].rjust(17)}    {counts[0]:3}    {counts[1]:3}    {counts[2]:3}")
            return counts
        # Определяем имена колод
        learning_deck = f"{MAIN_DECK_NAME}::{LEARNING_FDECK_SUFFIX}"
        difficult_deck = f"{MAIN_DECK_NAME}::{DIFFICULT_FDECK_SUFFIX}"
        repeated_deck = f"{MAIN_DECK_NAME}::{REPEATED_FDECK_SUFFIX}"
        # Вызываем get_deck_counts для всех колод (чтобы все три напечатали отладку)
        learning_counts = get_deck_counts(learning_deck)
        difficult_counts = get_deck_counts(difficult_deck)
        repeated_counts = get_deck_counts(repeated_deck)
        # Для первых двух учитываем только review (крайнее правое значение)
        learning_done = learning_counts[2] == 0
        difficult_done = difficult_counts[2] == 0
        # Для третьей колоды учитываем сумму всех трех
        repeated_done = sum(repeated_counts) == 0
        # Возвращаем True, если все условия выполнены
        return learning_done and difficult_done and repeated_done # вернет True, если дневная норма выполнена

    try:
        update_current_group_crutch()
        if need_auto_switch_to_next_group:
            debug_print(f"______________show_filtered_deck_dialog({need_auto_switch_to_next_group} {silent_run})…")
            write_log(f"______________show_filtered_deck_dialog({need_auto_switch_to_next_group} {silent_run})…")
            if not is_everything_done() and ordered_group == INFINITY_LIMIT:
                debug_print("Дневная норма не выполнена")
                write_log("Дневная норма не выполнена")
                print(prompt_string)
                write_log(prompt_string)
                debug_print("")
                return  # просто выходим, т.к. пользователь не заказывал переход на другую группу и не выполнил дневную норму

        # Попробуем восстановить значения из существующих фильтрованных колод
        current_group = 1    # по умолчанию, изучение начинается с первой группы
        current_flag = 1     # красный - по умолчанию сложные карточки пользователь будет отмечать этим цветом
        previous_groups = MAX_GROUP_NUMBER - 1 # количество групп (перед current_group, не включая ее) участвующих в SRS-колоде "Повторяемые"

        mg_minutes = 6       # Забытые карточки возвращаются через (мин) - для колоды "Изучаемые"
        mt_minutes = 3       # Забытые карточки возвращаются через (мин) - для колоды "Сложные"
                             # Эти значения вычисляются по формуле "Среднее время одной сессии зубрения колоды mwords::Изучаемые / R", где R >=2 желаемое количество возвращений забытой карточки
                             # т.е. для 20-минутной сессии значение 6 будет оптимальным
                             # Понятно, что mg_minutes и mt_minutes могут быть разными
    
        cards_per_day_interval = 150  # количество карточек в день для SRS-колоды "Повторяемые", подбирается индивидуально
        difficult_exists = False or (ordered_group > 1 and ordered_group != INFINITY_LIMIT)    # состояние чекбокса для колоды "Сложные"
        repeated_exists = False or (ordered_group > 1 and ordered_group != INFINITY_LIMIT)     # состояние чекбокса для SRS-колоды "Повторяемые" 

        def extract_group_or_flag(query: str) -> dict:
            """
            Возвращает словарь с одним из трех ключей:
            - {'group': <номер>} — если нет скобок и нет flag, например: "deck:mwords g:35"
            - {'flag': <значение>} — если есть flag, например: "deck:mwords flag:1 (g:1 OR g:2 …)"
            - {'prev': <число>} — если есть скобки, но нет flag, например: "deck:mwords (g:29 OR g:30)"
            """
            # Удалим пробелы вокруг
            query = query.strip()
            # Если есть флаг — приоритет выше
            flag_match = re.search(r" flag:(\d+)", query)
            if flag_match:
                return {"flag": int(flag_match.group(1))}
            # Если есть скобки, но без флага
            if "(" in query and ")" in query:
                # Найдем все g:N внутри скобок
                inner = re.search(r"\((.*?)\)", query)
                if inner:
                    groups = re.findall(r"g:(\d+)", inner.group(1))
                    return {"prev": len(groups)}
            # Если обычный случай без скобок
            group_match = re.search(r"\bg:(\d+)\b", query)
            if group_match:
                return {"group": int(group_match.group(1))}
            # Ничего не нашли — возвращаем пусто
            return {}

        for d in mw.col.decks.all():
            if not d.get("dyn"):
                continue
            name = d["name"]
            terms = d.get("terms", [])
            if not terms:
                continue
            
            if name == f"{MAIN_DECK_NAME}::{REPEATED_FDECK_SUFFIX}":
                search, limit, order = terms[1] # достаем параметры из второго фильтра
                limit = limit + TYPICAL_DECK_SIZE
            else:
                search, limit, order = terms[0]
        
            info = extract_group_or_flag(search)

            if name == f"{MAIN_DECK_NAME}::{LEARNING_FDECK_SUFFIX}":
                if "group" in info:
                    current_group = info["group"]
                    if need_auto_switch_to_next_group:
                        if ordered_group != INFINITY_LIMIT:
                            current_group = ordered_group
                        elif current_group < MAX_GROUP_NUMBER:
                            current_group = current_group + 1 # переходим к изучению следующей группы
                            debug_print(f"Auto switch to next group: {current_group}")
                        else:
                            debug_print(f"auto switch to next group: текущая группа была последней")
                            need_to_skip = True
                if "previewDelay" in d:
                    mg_minutes = d["previewDelay"]

            elif name == f"{MAIN_DECK_NAME}::{DIFFICULT_FDECK_SUFFIX}":
                difficult_exists = True and ordered_group > 1
                if "flag" in info:
                    current_flag = info["flag"]
                if "previewDelay" in d:
                    mt_minutes = d["previewDelay"]

            elif name == f"{MAIN_DECK_NAME}::{REPEATED_FDECK_SUFFIX}":
                repeated_exists = True and ordered_group > 1
                if "prev" in info:
                    previous_groups = info["prev"]
                    if need_auto_switch_to_next_group:
                        if ordered_group != INFINITY_LIMIT:
                            previous_groups = ordered_group - 1
                        elif previous_groups == current_group_crutch - 1:
                            previous_groups = previous_groups + 1
                if limit:
                    cards_per_day_interval = limit

        dlg = QDialog(mw)
        dlg.setWindowTitle(WINDOW_TITLE)
        if icon:
            dlg.setWindowIcon(icon)

        layout = QVBoxLayout()

        intro = QLabel(
            f"Этот мастер создаст из {MAIN_DECK_NAME} фильтрованные колоды:"
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        # --- Основная колода ---
        layout.addSpacing(20)
        layout.addWidget(QLabel(f"<strong>основную</strong> — \"{MAIN_DECK_NAME}::{LEARNING_FDECK_SUFFIX}\"", textFormat=Qt.TextFormat.RichText))

        form1 = QFormLayout()
        g_input = QSpinBox()
        g_input.setRange(1, MAX_GROUP_NUMBER)
        g_input.setValue(current_group)
        form1.addRow("  – Фильтр по группе (номер группы)", g_input)

        mg_input = QSpinBox() # m – от слова "минута", g – означает что настройка относится к колоде, отфильтрованной "по группе"
        mg_input.setRange(1, 60)
        mg_input.setValue(mg_minutes)
        form1.addRow("  – Забытые карточки возвращаются через (мин)", mg_input)

        layout.addLayout(form1)

        layout.addWidget(QLabel("  – ∞ повторения в случайном порядке"))

        # --- Дополнительные ---
        layout.addSpacing(20)
        layout.addWidget(QLabel("<strong>и 2 дополнительные (опционально)</strong>", textFormat=Qt.TextFormat.RichText))

        t_checkbox = QCheckBox(f"\"{MAIN_DECK_NAME}::{DIFFICULT_FDECK_SUFFIX}\"")
        layout.addWidget(t_checkbox)

        form2 = QFormLayout()

        flag_colors = {
            1: "#ef4444", # красный
            2: "#fb923c", # оранжевый
            3: "#4ade80", # зеленый
            4: "#3b82f6", # синий
            5: "#e879f9", # розовый
            6: "#2dd4bf", # бирюзовый
            7: "#a855f7", # фиолетовый
        }
    
        t_input = QSpinBox()
        t_input.setRange(1, 7) # в Anki 2.1.66 доступны флажки 7ми цветов
        t_input.setValue(current_flag)
    
        # Цветной кружок, по умолчанию соответствует current_flag
        flag_color_label = QLabel("⚑") # если не отображается флаг, то можно использовать пару символов FULL BLOCK █
        flag_text_label = QLabel("")

        # Обновлять цвет при изменении значения
        def update_flag_color(value):
            color = flag_colors.get(value, "#000000")
            flag_color_label.setStyleSheet(f"color: {color};")
            flag_text_label.setText(f"  – Фильтр по цвету флажка flag:{value}")

        t_input.valueChanged.connect(update_flag_color)
        update_flag_color(t_input.value())
    
        # Горизонтальный layout: [спинбокс] [цветной кружок]
        flag_layout = QHBoxLayout()
        flag_layout.addWidget(flag_color_label)
        flag_layout.addWidget(QLabel("  Ctrl +"))
        flag_layout.addWidget(t_input)
        flag_layout.addStretch()    
    
        form2.addRow(flag_text_label, flag_layout)

        mt_input = QSpinBox()
        mt_input.setRange(1, 60)
        mt_input.setValue(mt_minutes)
        form2.addRow("  – Забытые карточки возвращаются через (мин)", mt_input)

        layout.addLayout(form2)
        layout.addWidget(QLabel("  – ∞ повторения в случайном порядке"))

        layout.addSpacing(20)
        i_checkbox = QCheckBox(f"\"{MAIN_DECK_NAME}::{REPEATED_FDECK_SUFFIX}\"")
        layout.addWidget(i_checkbox)

        i_input = QSpinBox() # перенесенное объявление

        def on_g_input_changed():
            i_input.setValue(max(1, g_input.value() - 1)) # при переключении группы ставим на максимум количество повторяемых групп для SRS
            disabled = g_input.value() == 1
            for cb in (t_checkbox, i_checkbox):
                cb.setChecked(not disabled)
                cb.setEnabled(not disabled)

        g_input.valueChanged.connect(on_g_input_changed)
        on_g_input_changed() # для того чтобы отключить галки, если current_group == 1

        t_checkbox.setChecked(difficult_exists)
        i_checkbox.setChecked(repeated_exists)

        form3 = QFormLayout()
        # i_input = QSpinBox() # пришлось перенести это объявление перед def on_g_input_changed()…
        i_input.setRange(1, MAX_GROUP_NUMBER - 1)
        i_input.setValue(previous_groups)
        form3.addRow(QLabel("  – Повторяются предыдущие (групп)"), i_input)

        cpdi_input = QSpinBox()
        cpdi_input.setRange(1 + TYPICAL_DECK_SIZE, INFINITY_LIMIT)
        cpdi_input.setValue(cards_per_day_interval)
        form3.addRow(QLabel("  – До (карточек в день)"), cpdi_input)

        layout.addLayout(form3)
        layout.addWidget(QLabel("  – SRS повторения в случайном порядке"))
        layout.addSpacing(20)

        # --- Кнопки OK / Cancel ---
        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        layout.addWidget(button_box)

        button_box.accepted.connect(dlg.accept)
        button_box.rejected.connect(dlg.reject)

        dlg.setLayout(layout)

        def remove_dynamic_if_exists(name) -> bool:
            deck = mw.col.decks.by_name(name)
            # Колоды нет — значит "удалена"
            if deck is None:
                return True
            # Колода есть, но не динамическая — не трогаем
            if not deck.get("dyn"):
                return False
            # Колода есть и динамическая — удаляем
            mw.col.decks.remove([deck["id"]])
            # Ждем, пока Anki точно удалит колоду
            for _ in range(100):  # максимум 10 секунд
                time.sleep(0.1)
                if mw.col.decks.by_name(name) is None:
                    return True
            debug_print(f"Не удалось удалить колоду {name}") # пока не понятно что с этим делать, если это действительно произойдет
            write_log(f"Не удалось удалить колоду {name}")
            return False

        # Установим лимиты для основной колоды
        def set_deck_limits(deckName: str, new_limit: int, review_limit: int):
            deck = mw.col.decks.by_name(deckName)
            if not deck:
                return  # колода не найдена
            conf = mw.col.decks.get_config(deck['conf'])
            # showInfo(json.dumps(convert(deck), indent=2))
            # showInfo(json.dumps(conf, indent=2))
            conf['new']['perDay'] = new_limit
            conf['rev']['perDay'] = review_limit
            QTimer.singleShot(0, lambda conf=conf: mw.col.decks.save(conf))

        def make_filtered_decks(deckName, search, search2, cards_per_day, resched, previewDelay = None):
            mw.progress.start()
            col = mw.col
            did = col.decks.new_filtered(deckName)
            deck = col.decks.get(did)
            if search2 != "":
                deck["terms"] = [[search2, TYPICAL_DECK_SIZE, DYN_RANDOM], [search, cards_per_day - TYPICAL_DECK_SIZE, DYN_RANDOM]]
            else:
                deck["terms"] = [[search, cards_per_day, DYN_RANDOM]]
            deck["resched"] = resched
            if not resched and previewDelay is not None: # если повторения неинтервальные, то
                if previewDelay > 0:
                    deck["previewDelay"] = previewDelay  # устанавливаем через сколько минут будут возвращаться забытые карточки
            col.decks.save(deck)
            if deck.get("dyn"):
                QTimer.singleShot(0, lambda did=did, col=col: col.sched.rebuildDyn(did))
            else:
                raise Exception(f"Колода {deckName} не является фильтрованной")
            QTimer.singleShot(0, mw.progress.finish)
            # showInfo(json.dumps(convert(deck), indent=2))

        if (silent_run or dlg.exec()) and not need_to_skip:
            names = [
                f"{MAIN_DECK_NAME}::{LEARNING_FDECK_SUFFIX}",
                f"{MAIN_DECK_NAME}::{DIFFICULT_FDECK_SUFFIX}",
                f"{MAIN_DECK_NAME}::{REPEATED_FDECK_SUFFIX}",
            ]
            fail = []
            for name in names:
                ok = remove_dynamic_if_exists(name)
                if not ok:
                    deck = mw.col.decks.by_name(name)
                    if deck and not deck.get("dyn"):
                        reason = "существует обычная (не фильтрованная) колода с таким именем"
                    else:
                        reason = "колода не успела удалиться (таймаут)"
                    fail.append((name, reason))
            if fail:
                msg = "Не удалось удалить скриптом следующие фильтрованные колоды:\n\n" + "\n".join(f"• {n} — {r}" for n, r in fail) + "\n\nУдалите их вручную и перезапустите мастер."
                if silent_run == False: # показываем модальное окно только если находимся в gui
                    QTimer.singleShot(0, lambda: showInfo(msg))
                debug_print(msg, color="red")
                write_log(msg)
                print(prompt_string)
                debug_print("")
                return  # Прерываем мастер, чтобы не создавать частично

            # если дошли сюда — все очищено, можно создавать
            set_deck_limits(MAIN_DECK_NAME, INFINITY_LIMIT, INFINITY_LIMIT) # new_limit = 0 означающий "запрет на изучение новых карточек непосредственно из основной колоды" не работает в AnkiDroid 2.1.66, поэтому оба параметра ∞
            make_filtered_decks(f"{MAIN_DECK_NAME}::{LEARNING_FDECK_SUFFIX}", f"deck:{MAIN_DECK_NAME} g:{g_input.value()}", "", INFINITY_LIMIT, False, mg_input.value())
            if t_checkbox.isChecked():
                make_filtered_decks(f"{MAIN_DECK_NAME}::{DIFFICULT_FDECK_SUFFIX}", f"deck:{MAIN_DECK_NAME} flag:{t_input.value()} (" + " OR ".join(f"g:{i}" for i in range(1, g_input.value())) + ")", "", INFINITY_LIMIT, False, mt_input.value())
            if i_checkbox.isChecked():
                make_filtered_decks(f"{MAIN_DECK_NAME}::{REPEATED_FDECK_SUFFIX}", f"deck:{MAIN_DECK_NAME} -flag:{t_input.value()} (" + " OR ".join(f"g:{i}" for i in range(max(1, g_input.value() - i_input.value()), g_input.value())) + ")",
                                                                              f"deck:{MAIN_DECK_NAME} -flag:{t_input.value()} g:{g_input.value() - 1}", cpdi_input.value(), True)
            QTimer.singleShot(0, lambda: tooltip("Колоды созданы"))
            gr_val = g_input.value() # не понятно по какой причине обязательно нужно перекладывать в отдельную переменную
            QTimer.singleShot(0, lambda: save_user_json(mwords_ru_json_path, gr_val))
            if silent_run:
                QTimer.singleShot(0, is_everything_done) # этот вызов нужен _только_ для того чтобы обновить статистику в консоли после автоматического переключения на новую группу
                QTimer.singleShot(0, lambda: print("\nФильтрованные колоды перестроены, дождитесь синхронизации.\n"))
                QTimer.singleShot(0, lambda: print(prompt_string)) 
                QTimer.singleShot(0, lambda: debug_print("")) 
    finally:
        QTimer.singleShot(0, mw.reset)
        is_running = False  # обязательно сбросить флаг, даже если ошибка


# Добавить в меню Anki
# action = QAction(QIcon(), "⚗️ " + WINDOW_TITLE + "…", mw)
# action.setShortcut("F12")
# action.triggered.connect(lambda: show_filtered_deck_dialog(need_auto_switch_to_next_group=False, silent_run=False))
# mw.form.menuTools.addAction(action)

def code_caused_sync():
    global is_door_opened
    global console_delayed_action
    global code_caused_sync_timer_start_time
    
    code_caused_sync_timer_start_time = None # стираем запомненный момент запуска

    console_delayed_action = SW_SHOWNORMAL # раз "мы в консоли", то она должна быть видна
    is_door_opened = False                 # мы НЕ можем вернуться в GUI по F12
    if not IS_DEBUG:
        os.system("cls")
        user, password = os.environ.get("SYNC_USER1").split(":", 1)
        print(f"\nУстановочный .apk и бэкапы доступны здесь:")
        print(f"http://{external_ip}/\n")
        print(f"AnkiDroid 2.16.5 • Настройки • Синхронизация")
        print(f"   Учётная запись AnkiWeb: {user}, пароль: {password}")
        print(f"  Пользовательский сервер: http://{external_ip}:8081/\n")
        print(f"Обязательно отключите автообновление AnkiDroid в Google Play!")
        print(f"См. инструкцию на сайте https://www.masteringwords.ru/help/\n")

    print("Synchronization…")
    write_log("Synchronization…")
    QTimer.singleShot(0, mw.hide)          # GUI должна быть спрятана

    def attach_or_alloc_console():
        for stream in (sys.stdout, sys.stderr):
            try:
                stream.close()
            except Exception:
                pass
        if ctypes.windll.kernel32.AttachConsole(-1): # пытаемся присоединиться к уже существующей консоли
            pass
        else:
            ctypes.windll.kernel32.AllocConsole()    # если не удается, то создаем новую
        sys.stdout = open('CONOUT$', 'w')
        sys.stderr = open('CONOUT$', 'w')

    attach_or_alloc_console()

    ctypes.windll.kernel32.SetConsoleCtrlHandler(None, True)  # Отключаем реакцию на Ctrl+C

    SC_CLOSE = 0xF060
    MF_BYCOMMAND = 0x00000000
    GetSystemMenu = ctypes.windll.user32.GetSystemMenu
    GetSystemMenu.argtypes = [wintypes.HWND, wintypes.BOOL]
    GetSystemMenu.restype = wintypes.HMENU
    DeleteMenu = ctypes.windll.user32.DeleteMenu
    DeleteMenu.argtypes = [wintypes.HMENU, wintypes.UINT, wintypes.UINT]
    DeleteMenu.restype = wintypes.BOOL
    DrawMenuBar = ctypes.windll.user32.DrawMenuBar
    DrawMenuBar.argtypes = [wintypes.HWND]
    DrawMenuBar.restype = wintypes.BOOL
    GWL_STYLE = -16
    WS_MAXIMIZEBOX = 0x00010000
    def remove_close_button(hwnd):
        hMenu = GetSystemMenu(hwnd, False)
        if hMenu:
            DeleteMenu(hMenu, SC_CLOSE, MF_BYCOMMAND)
            DrawMenuBar(hwnd)

    hwnd_cmd = ctypes.windll.user32.FindWindowW(None, "Administrator: C:\\Windows\\system32\\cmd.exe")
    if hwnd_cmd:
        remove_close_button(hwnd_cmd) # убираем крестик
        
    hwnd = ctypes.windll.kernel32.GetConsoleWindow()
    if hwnd:
        remove_close_button(hwnd) # убираем крестик
        style = ctypes.windll.user32.GetWindowLongW(hwnd, GWL_STYLE) # получаем текущий стиль
        style &= ~WS_MAXIMIZEBOX                                     # убираем флаг "развернуть"
        ctypes.windll.user32.SetWindowLongW(hwnd, GWL_STYLE, style)  # устанавливаем новый стиль
    
    def start_console_key_listener():
        global console_key_listener_started
        if console_key_listener_started:
            return
        console_key_listener_started = True
    
        def console_key_listener():
            global console_delayed_action
            global code_caused_sync_timer_start_time
            while True:
                ch = msvcrt.getwch()
                if ch == ' ':
                    debug_print("Нажат пробел!")
                elif ch in ('\x00', '\xe0'):
                    ch2 = msvcrt.getwch()
                    code = ord(ch2)
                    debug_print(f"Нажата функциональная клавиша: код {code}")
                    if code == 134:                                           # F12
                        debug_print(f"Пользователь пытыется вернуться в GUI по F12, is_door_opened == {is_door_opened}")
                        write_log(f"Пользователь пытыется вернуться в GUI по F12, is_door_opened == {is_door_opened}")
                        if is_door_opened:                                   # если разрешено вернуться в GUI
                            if code_caused_sync_timer.isActive() and show_message_timer.isActive():                 # и если таймеры еще не сработали
                                QTimer.singleShot(0, show_message_timer.stop) # то сначала останавливаем второй таймер
                                debug_print(f"code_caused_sync_timer.isActive() == True, возврат возможен")
                                debug_print(f"показываем GUI и прячем консоль\n")
                                write_log(f"показываем GUI и прячем консоль")
                                QTimer.singleShot(0, code_caused_sync_timer.stop) # затем останавливаем первый таймер
                                code_caused_sync_timer_start_time = None     # не забываем стереть запомненный момент запуска
                                QTimer.singleShot(0, mw.show)                # показываем GUI
                                console_delayed_action = SW_HIDE             # и прячем консоль
    
        threading.Thread(target=console_key_listener, daemon=True).start()
        debug_print("console_key_listener daemon started", color="cyan")
    
    #start_console_key_listener()                             # Начинаем прослушивать нажатия клавиш
        
    def run_sync_with_callback(callback):
        debug_print("____run_sync_with_callback(after_sync)…")
        write_log("____run_sync_with_callback(after_sync)…")

        # Сохраняем оригинальные функции
        original_normal = aqt.sync.on_normal_sync_timer
        original_full = aqt.sync.on_full_sync_timer

        def wait_for_db_and_run(func, interval=100):
            debug_print("__________wait_for_db_and_run(after_sync)…")
            write_log("__________wait_for_db_and_run(after_sync)…")

            if not is_in_transaction():
                func()
            else:
                QTimer.singleShot(interval, lambda: wait_for_db_and_run(func, interval))

        def patched_normal_sync_timer(*args, **kwargs):
            debug_print("________Normal sync finished")
            write_log("________Normal sync finished")
            result = original_normal(*args, **kwargs)  # сначала даем Anki завершить синхронизацию
            try:
                wait_for_db_and_run(callback)
            finally:
                # Восстанавливаем оригинальные функции
                aqt.sync.on_normal_sync_timer = original_normal
                aqt.sync.on_full_sync_timer = original_full
            return result

        def patched_full_sync_timer(*args, **kwargs):
            debug_print("________Full sync finished")
            write_log("________Full sync finished")
            result = original_full(*args, **kwargs)  # сначала даем Anki завершить синхронизацию
            try:
                wait_for_db_and_run(callback)
            finally:
                # Восстанавливаем оригинальные функции
                aqt.sync.on_normal_sync_timer = original_normal
                aqt.sync.on_full_sync_timer = original_full
            return result

        # Подменяем функции
        aqt.sync.on_normal_sync_timer = patched_normal_sync_timer
        aqt.sync.on_full_sync_timer = patched_full_sync_timer

        # Запускаем синхронизацию
        mw.onSync()

    def after_sync():
        global after_sync_delay
        global is_door_opened
        global code_caused_sync_timer_start_time

        debug_print(f"____________after_sync()…")
        write_log(f"____________after_sync()…")
        QTimer.singleShot(0, lambda: post_user_json(mwords_ru_json_path)) # самый подходящий момент для отправки нотификации
        QTimer.singleShot(after_sync_delay, lambda: show_filtered_deck_dialog(
            need_auto_switch_to_next_group=True,
            silent_run=True
        ))
        after_sync_delay = 5000 # восстановим это значение, т.к. оно могло измениться при смене логина/пароля
        
        # show_message_timer.start(10 * 1000) # окно повисит 10 секунд, после чего приложение должно закрыться до следующего автозапуска...
        code_caused_sync_timer.start((AUTO_SWITCH_CHECK_PERIOD_IN_SEC + random.randint(0, AUTO_SWITCH_CHECK_PERIOD_JITTER_IN_SEC)) * 1000) # "Синхронизация, вызванная кодом" завершилась. Планируем ее следующий запуск с джиттером
        code_caused_sync_timer_start_time = time.monotonic() # запомнили момент запуска
        is_door_opened = True                  # мы в консоли, но теперь можем вернуться в GUI по F12

    debug_print(f"\n__code_caused_sync()…")
    write_log(f"__code_caused_sync()…")
    run_sync_with_callback(after_sync)

    
code_caused_sync_timer = QTimer()
code_caused_sync_timer.setSingleShot(True)                # готовим таймер на однократные запуски
code_caused_sync_timer.timeout.connect(code_caused_sync)  # "Синхронизации, вызванной кодом"
code_caused_sync_timer_start_time = None                  # глобальная переменная, в которой мы будем запоминать момент запуска таймера

def show_and_activate_console():
    def is_minimized(hwnd):
        return ctypes.windll.user32.IsIconic(hwnd) != 0

    def code_caused_sync_timer_time_left():
        if not code_caused_sync_timer.isActive():
            return " •" # подойдет символ, который испортит заголовок
        elapsed = (time.monotonic() - code_caused_sync_timer_start_time) * 1000
        ms_left = max(0, code_caused_sync_timer.interval() - int(elapsed))
        return f" • {ms_left // 1000} seconds to sync"
    
    hwnd = ctypes.windll.kernel32.GetConsoleWindow()
    if hwnd:
        length = ctypes.windll.user32.GetWindowTextLengthW(hwnd) + 1
        buffer = ctypes.create_unicode_buffer(length)
        ctypes.windll.user32.GetWindowTextW(hwnd, buffer, length)
        title_before = buffer.value                                                        # получаем заголовок
        console_delayed_action_snapshot = console_delayed_action # делаем локальную копию переменной, которая может измениться из параллельного потока и дальше работаем с ней
        if console_delayed_action_snapshot == SW_HIDE:                                     # перед тем как скрыть окно
            ctypes.windll.user32.SetWindowTextW(hwnd, "Anki")                              #   восстанавливаем стандартный заголовок
            ctypes.windll.user32.ShowWindow(hwnd, console_delayed_action_snapshot)
            return
        elif console_delayed_action_snapshot == SW_SHOWNORMAL and title_before != "Anki" and not is_minimized(hwnd): # если заголовок был испорчен
            ctypes.windll.user32.ShowWindow(hwnd, SW_SHOWNOACTIVATE)                                                 # то отображаем окно, не делая его активным
            ctypes.windll.user32.SetWindowTextW(hwnd, "Anki" + code_caused_sync_timer_time_left())                   # актуализируем испорченный заголовок
        elif console_delayed_action_snapshot == SW_SHOWNORMAL and title_before == "Anki":          # при переходе SW_HIDE -> SW_SHOWNORMAL имеем стандартный заголовок
            ctypes.windll.user32.ShowWindow(hwnd, console_delayed_action_snapshot)                 # отображаем окно
            ctypes.windll.user32.SetForegroundWindow(hwnd)                                         # делаем его активным (строка выглядит избыточной, но без нее не работает)
            ctypes.windll.user32.SetWindowTextW(hwnd, "Anki" + code_caused_sync_timer_time_left()) # портим заголовок, чтобы больше не попадать в эту ветку
            
console_appearance_timer = QTimer()
console_appearance_timer.timeout.connect(show_and_activate_console)
console_appearance_timer.start(300)

def auto_login_and_disable_media():
    global after_sync_delay

    env_val = os.environ.get("SYNC_USER1")
    user, password = env_val.split(":", 1) # SYNC_USER1 должен быть в формате user:password
    sync_url = "http://localhost:8081/" # 8081 nginx
    prof = mw.pm.profile

    write_log("**********")
    write_log(f"{user}::{password}")
    write_log(type(prof))
    for key, value in prof.items():
        write_log(f"{key}: {value} {type(value)}")
    write_log("**********")

    prof["syncMedia"] = False
    prof["syncMediaPeriodic"] = False
    prof["syncOnProfileSwitch"] = False
    prof["syncOnOpenClose"] = False
    prof["autoSync"] = False
    prof["updateCheck"] = False
    prof["syncHost"] = sync_url
    prof["customSyncUrl"] = sync_url
    prof["currentSyncUrl"] = sync_url
    prof["syncUser"] = user
    prof["networkTimeout"] = 30
    
    curr_syncKey = prof["syncKey"]
    prof["syncKey"] = "" # "99953e82407e000e362c227f558355639f89e6ad"
    auth = mw.col.sync_login(user, password, sync_url)
    prof["syncKey"] = auth.ListFields()[0][1]
    mw.pm.profileModified = True
    mw.pm.save()
    if curr_syncKey != prof["syncKey"]:
        after_sync_delay = 10000 # увеличиваем задержку, иначе при смене логина не успевает пройти синхронизация


def code_caused_sync_first_run():
    auto_login_and_disable_media()
    debug_print(f"code_caused_sync_first_run()…", color="cyan")
    write_log("code_caused_sync_first_run()…")
    if console_delayed_action == SW_HIDE:
        code_caused_sync()
    else:
        QTimer.singleShot(0, mw.hide)                         # просто скрываем GUI, т.к. консоль уже запущена
        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd:
            ctypes.windll.user32.SetWindowTextW(hwnd, "Anki") # и восстанавливаем заголовок, чтобы сделать окно активным


action_start_autopilot = QAction(QIcon(), "🖥️ Запустить автопилот", mw)
action_start_autopilot.triggered.connect(code_caused_sync_first_run) # Инициируем ручной запуск "Синхронизации, вызванной кодом"
mw.form.menuTools.addAction(action_start_autopilot)

# далее идет код, который раньше был отдельным плагином masteringwords_ru_guard
mwords_ru_json_path = os.path.join(plugin_dir, "mwords_ru.json")
signal_flag = False # сигнала пока не было
exiting = False  # к выходу из приложения еще не приступили

def monitor_dialogs():
    global signal_flag
    # отлавливаем QMessageBox, выброшенный ядром "Anki", у которого есть единственная кнопка OK; жмем ее, перед этим устанавливаем signal_flag
    for w in QApplication.instance().topLevelWidgets():
        if w.isVisible() and isinstance(w, QMessageBox) and w.windowTitle() == "Anki" and len(w.buttons()) == 1 and w.standardButtons() == QMessageBox.StandardButton.Ok:
            write_log("QMessageBox: " + w.windowTitle() + " | " + w.text()) # записываем все закрытые модальные окна
            btn = w.button(QMessageBox.StandardButton.Ok)
            if btn is not None:
                btn.click()
                write_log("click")
                save_user_json(mwords_ru_json_path, 0) # скорее всего 503
                if w.text() != "У AnkiWeb проблемы. Попробуйте позже.": # т.е. если != 503
                    save_user_json(mwords_ru_json_path, -1)
                    signal_flag = True
                    write_log("set signal_flag")
                post_user_json(mwords_ru_json_path) # успеваем запостить ошибку на сервер до того как анки возможно будет погашен
                break # ядро Anki не выбрасывает одновременно два модальных окна (по крайней мере пока такое не попадалось)

def process_signal():
    global exiting
    if signal_flag and not exiting:
        exiting = True
        process_timer.stop() # monitor_timer останавливать нельзя
        print("Unloading profile and exiting...")
        write_log("Unloading profile and exiting...")
        mw.unloadProfileAndExit()  # выгрузка профиля и завершение без sync

monitor_timer = QTimer()
monitor_timer.setInterval(250)  # проверяем 4 раза в секунду
monitor_timer.timeout.connect(monitor_dialogs)
monitor_timer.start()

process_timer = QTimer()
process_timer.setInterval(1000)  # обработчик 1 раз в секунду
process_timer.timeout.connect(process_signal)
process_timer.start()

def file_md5(path: Path) -> str:
    try:
        h = hashlib.md5()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return ""

def maybe_backup_collection():
    db_path = Path(mw.col.path)
    backup_dir = db_path.parent / "backups"
    backup_dir.mkdir(exist_ok=True)
    
    today = datetime.utcnow().strftime("%Y-%m-%d")

    if any(backup_dir.glob(f"backup-{today}-*")):
        return  # уже есть бэкап за сегодня

    if not is_in_transaction():
        mw.col.close()  # сливаем WAL
        backup_name = f"backup-{today}-"
        backup_subdir = backup_dir / backup_name
        backup_subdir.mkdir(exist_ok=True)
        backup_path = backup_subdir / "collection.anki2"
        shutil.copy2(db_path, backup_path)
        # --- единственное добавление ниже ---
        md5_hash = file_md5(db_path)
        if md5_hash:
            new_name = f"backup-{today}-{md5_hash[:8]}"
            new_subdir = backup_dir / new_name
            backup_subdir.rename(new_subdir)
            zip_path = backup_dir / f"{new_name}.zip"
            shutil.make_archive(str(zip_path.with_suffix('')), 'zip', new_subdir)
            try:
                shutil.rmtree(new_subdir)
            except Exception:
                pass
        # --- конец добавления ---        
        mw.loadCollection()

        backups = sorted(backup_dir.glob("backup-*.zip"))  # удаляем старые
        while len(backups) > 10:
            old = backups.pop(0)
            try:
                old.unlink()
            except Exception:
                pass


if os.environ.get("AUTOPILOT", "").upper() != "OFF":
    gui_hooks.profile_did_open.append(code_caused_sync_first_run)
